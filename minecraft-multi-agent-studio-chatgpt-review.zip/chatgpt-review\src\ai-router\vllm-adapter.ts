import type { AIAdapter, GenerateOptions, GenerateResult, HealthResult } from '../types/adapter.js';
import { z } from 'zod';

function sanitizeVllmJsonSchema(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sanitizeVllmJsonSchema);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(
    Object.entries(value)
      .filter(([key]) => key !== 'propertyNames')
      .map(([key, entry]) => [key, sanitizeVllmJsonSchema(entry)]),
  );
}

const chatCompletionResponseSchema = z
  .object({
    choices: z
      .array(
        z
          .object({
            message: z.object({ content: z.string() }).loose(),
          })
          .loose(),
      )
      .min(1),
    usage: z
      .object({
        prompt_tokens: z.number().int().nonnegative(),
        completion_tokens: z.number().int().nonnegative(),
      })
      .loose(),
  })
  .loose();

const modelListResponseSchema = z
  .object({
    data: z.array(z.object({ id: z.string().min(1) }).loose()).min(1),
  })
  .loose();

export class VLLMAdapter implements AIAdapter {
  readonly name = 'vllm';
  readonly type = 'local' as const;

  constructor(
    private readonly baseUrl: string,
    private readonly model: string,
    private readonly apiKey?: string | null,
  ) {}

  private requestHeaders(contentType?: string): Record<string, string> {
    return {
      Accept: 'application/json',
      ...(contentType ? { 'Content-Type': contentType } : {}),
      ...(this.apiKey?.trim()
        ? { Authorization: `Bearer ${this.apiKey.trim()}` }
        : {}),
    };
  }

  async health(): Promise<HealthResult> {
    const start = Date.now();
    try {
      const response = await fetch(`${this.baseUrl}/health`, {
        headers: this.requestHeaders(),
        signal: AbortSignal.timeout(5000)
      });
      if (response.ok) {
        return { available: true, latencyMs: Date.now() - start };
      }
      // Ollama and some other OpenAI-compatible hubs do not expose /health,
      // but do expose the standard model discovery endpoint. Only fall back
      // for an absent endpoint; preserve real upstream failures as unavailable.
      if (response.status !== 404 && response.status !== 405) {
        return {
          available: false,
          latencyMs: Date.now() - start,
          error: `HTTP ${response.status}`,
        };
      }
      const modelsResponse = await fetch(`${this.baseUrl}/v1/models`, {
        headers: this.requestHeaders(),
        signal: AbortSignal.timeout(5000),
      });
      if (!modelsResponse.ok) {
        return {
          available: false,
          latencyMs: Date.now() - start,
          error: `HTTP ${modelsResponse.status}`,
        };
      }
      const models = modelListResponseSchema.parse(await modelsResponse.json());
      const modelAvailable = models.data.some(({ id }) => id === this.model);
      return {
        available: modelAvailable,
        latencyMs: Date.now() - start,
        ...(modelAvailable ? {} : { error: `Model ${this.model} is not advertised.` }),
      };
    } catch (error) {
      return {
        available: false,
        latencyMs: Date.now() - start,
        error: error instanceof Error ? error.message : String(error)
      };
    }
  }

  async generate(request: GenerateOptions): Promise<GenerateResult> {
    const controller = new AbortController();
    const timeout = setTimeout(
      () => controller.abort(new Error(`vLLM request exceeded ${request.timeoutMs}ms.`)),
      request.timeoutMs,
    );
    const abortFromCaller = () => controller.abort(request.signal?.reason);
    if (request.signal?.aborted) abortFromCaller();
    else request.signal?.addEventListener('abort', abortFromCaller, { once: true });

    try {
      const response = await fetch(`${this.baseUrl}/v1/chat/completions`, {
        method: 'POST',
        headers: this.requestHeaders('application/json'),
        body: JSON.stringify({
          model: this.model,
          messages: [
            ...(request.systemPrompt ? [{ role: 'system', content: request.systemPrompt }] : []),
            { role: 'user', content: request.prompt }
          ],
          // Ornith is a Qwen reasoning model. Planner decisions belong in the
          // structured content channel; leaving thinking enabled can consume
          // the whole bounded response with reasoning and return content=null.
          chat_template_kwargs: { enable_thinking: false },
          max_tokens: request.maxTokens,
          temperature: request.temperature,
          ...(request.schema
            ? {
                response_format: {
                  type: 'json_schema',
                  json_schema: {
                    name: 'structured_response',
                    strict: true,
                    schema: sanitizeVllmJsonSchema(z.toJSONSchema(request.schema)),
                  },
                },
              }
            : {}),
        }),
        signal: controller.signal
      });

      if (!response.ok) {
        throw new Error(`vLLM error: ${response.status} ${response.statusText}`);
      }

      const data = chatCompletionResponseSchema.parse(await response.json());
      const choice = data.choices[0];
      if (!choice) throw new Error('vLLM response did not contain a completion choice.');
      return {
        content: choice.message.content,
        usage: {
          promptTokens: data.usage.prompt_tokens,
          completionTokens: data.usage.completion_tokens
        }
      };
    } finally {
      clearTimeout(timeout);
      request.signal?.removeEventListener('abort', abortFromCaller);
    }
  }
}
